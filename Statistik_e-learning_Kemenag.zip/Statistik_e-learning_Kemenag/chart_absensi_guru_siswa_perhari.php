<?php require_once('Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_database, $database);
$query_rsChartSiswa = "SELECT tanggal, count(DISTINCT tmsiswa_id) AS total FROM tr_absensisiswa GROUP BY tanggal ORDER BY tanggal DESC";
$rsChartSiswa = mysql_query($query_rsChartSiswa, $database) or die(mysql_error());
$row_rsChartSiswa = mysql_fetch_assoc($rsChartSiswa);
$totalRows_rsChartSiswa = mysql_num_rows($rsChartSiswa);

mysql_select_db($database_database, $database);
$query_rsChartGuru = "SELECT tanggal, count(id) AS total FROM tr_absensi GROUP BY tanggal ORDER BY tanggal DESC";
$rsChartGuru = mysql_query($query_rsChartGuru, $database) or die(mysql_error());
$row_rsChartGuru = mysql_fetch_assoc($rsChartGuru);
$totalRows_rsChartGuru = mysql_num_rows($rsChartGuru);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/highcharts.js" type="text/javascript"></script>
<script type="text/javascript">
	var chart1; // globally available
$(document).ready(function() {
      chart1 = new Highcharts.Chart({
         chart: {
            renderTo: 'container',
            type: 'column'
         },   
         title: {
            text: 'Grafik Harian Siswa'
         },
         xAxis: {
            categories: ['Login Harian Siswa']
         },
         yAxis: {
            title: {
               text: 'Jml Siswa Per-Hari'
            }
         },
              series:             
            [
            <?php 
        	
           $sql   = "SELECT tanggal  FROM tr_absensisiswa GROUP BY tanggal ORDER BY tanggal ASC";
            $query = mysql_query( $sql )  or die(mysql_error());
            while( $ret = mysql_fetch_array( $query ) ){
            	$tanggal=$ret['tanggal'];                     
                 $sql_total   = "SELECT count(DISTINCT tmsiswa_id) AS total FROM tr_absensisiswa WHERE tanggal='$tanggal'";        
                 $query_total = mysql_query( $sql_total ) or die(mysql_error());
                 while( $data = mysql_fetch_array( $query_total ) ){
                    $total = $data['total'];  
					$tanggal_siswa=$data_tanggal=date('d-m-Y', strtotime($ret['tanggal']));                
                  }             
                  ?>
                  {
                      name: '<?php echo $tanggal_siswa; ?>',
                      data: [<?php echo $total; ?>]
                  },
                  <?php } ?>
            ]
      });
   });	
</script>

<!--script grafik guru-->
<script type="text/javascript">
	var chart2; // globally available
$(document).ready(function() {
      chart1 = new Highcharts.Chart({
         chart: {
            renderTo: 'containerguru',
            type: 'column'
         },   
         title: {
            text: 'Grafik Harian Guru'
         },
         xAxis: {
            categories: ['Login Harian Guru']
         },
         yAxis: {
            title: {
               text: 'Jml Guru Per-Hari'
            }
         },
              series:             
            [
            <?php 
        	
           $sql   = "SELECT tanggal  FROM tr_absensi GROUP BY tanggal ORDER BY tanggal ASC";
            $query = mysql_query( $sql )  or die(mysql_error());
            while( $ret = mysql_fetch_array( $query ) ){
            	$tanggal=$ret['tanggal'];                     
                 $sql_total   = "SELECT count(id) AS total FROM tr_absensi WHERE tanggal='$tanggal' ";        
                 $query_total = mysql_query( $sql_total ) or die(mysql_error());
                 while( $data = mysql_fetch_array( $query_total ) ){
                    $total = $data['total'];  
					$tanggal_guru=$data_tanggal=date('d-m-Y', strtotime($ret['tanggal']));                
                  }             
            ?>
                  {
                      name: '<?php echo $tanggal_guru; ?>',
                      data: [<?php echo $total; ?>]
                  },
                  <?php } ?>
            ]
      });
   });	
</script>

</head>

<body width="100%">
<div class="content-wrapper" style="min-height: 984.83px;"> 
<h5>Grafik harian </h5>
<div class="col-xs-2">
<div class="box box-primary">
<div class="row" align="center">
            <div class="col-md-6">
                <div class="box box-solid box-default">
                  <div class="box-header">
                        <h6>Grafik Siswa</h6>
                    </div>
                    <!-- /.box-Grafik-Siswa-header -->
                    <div id='container'></div>
                  <div class="box-body"><strong><a href="dashboard.php?page=chartsiswaharian">Siswa </a></strong><a href="dashboard.php?page=chartsiswaharian"> Online</a><br>
                  </div>
                  <!-- /.box-body -->
                </div><!-- /.box -->
            </div>
            <div class="col-md-6">
                <div class="box box-solid box-primary">
                  <div class="box-header">
                        <h6 class="box-title">Grafik Guru</h6>
                  </div>
                  <!-- /.box-header -->
                  <div id='containerguru'></div>	
                  <div class="box-body">
                  <strong><a href="dashboard.php?page=chartguruharian">Guru </a></strong><a href="dashboard.php?page=chartguruharian"> Online</a></div>
                    <!-- /.box-body -->
                </div><!-- /.box -->
            </div>
            <div class="col-md-3"><!-- /.box -->
            </div>
        <div class="clearfix"></div>
</div>
<p>&nbsp;</p>
<h5>Tabel Login Harian Siswa dan Guru
  </head>
  <body>
  <script>
        var barchart = document.getElementById('bar-chart');
        var chart = new Chart(barchart, {
          type: 'bar',
          data: {
            labels: <?php echo json_encode($data_tanggal) ?>, // Merubah data tanggal menjadi format JSON
            datasets: [{
              label: 'Data Penjualan',
              data: <?php echo json_encode($data_total) ?>,
              backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)'
              ],
              borderColor: [
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)'
              ],
              borderWidth: 2
            }]
          }
        });

        var linechart = document.getElementById('line-chart');
        var chart = new Chart(linechart, {
          type: 'line',
          data: {
            labels: <?php echo json_encode($data_tanggal) ?>, // Merubah data tanggal menjadi format JSON
            datasets: [{
              label: 'Data Penjualan',
              data: <?php echo json_encode($data_total) ?>,
              borderColor: 'rgba(255,99,132,1)',
              backgroundColor: 'transparent',
              borderWidth: 2
            }]
          }
        });
      </script>
  
  
</h5>
<h6>Jumlah Siswa terhadap Hari Berjalan : <strong><?php echo $totalRows_rsChartSiswa ?></strong>
      Hari
      </h6>
    <table border="0" align="center" class="table table-hover"  style="font-size:1vw;">
        <tr>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>No.</strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Tanggal.Eng</strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Tanggal.Id</strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Ket.
            <?php
include 'time.php';
ini_set('date.timezone', 'Asia/Jakarta');

$jam_jalan = date('Y-m-d H:i:s');

?>
          </strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Jml.Siswa/Hari</strong></td>
        </tr>
        <?php $no=0; do { $no++; ?>
        <tr>
          <td><?php echo "$no";?></td>
          <td><?php echo $row_rsChartSiswa['tanggal']; ?></td>
          <td align="center" nowrap="nowrap"><?php $data_tanggal=date('d-m-Y', strtotime($row_rsChartSiswa['tanggal'])); echo $data_tanggal; ?></td>
          <td align="center" nowrap="nowrap"><?php
  $timestamp = $row_rsChartSiswa['tanggal'];
  
date_default_timezone_set('Asia/Jakarta');
  tgl_indo($jam_jalan); 
?>            <?php echo tgl_indo($timestamp); ?></td>
          <td align="center" nowrap="nowrap"><?php echo $row_rsChartSiswa['total']; ?></td>
        </tr>
        <?php } while ($row_rsChartSiswa = mysql_fetch_assoc($rsChartSiswa)); ?>
      </table>
    <p><center>
        <h6>Jumlah Guru terhadap Hari Berjalan : <strong><?php echo $totalRows_rsChartGuru ?></strong>
      Hari
        </h6>
    </center></p>
      <table border="0" align="center" class="table table-hover"  style="font-size:1vw;">
        <tr>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC">No</td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Tanggal.Eng</strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Tanggal.Id</strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Ket.
            
          </strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Jml.Guru/Hari</strong></td>
        </tr>
        <?php $no=0; do { $no++; ?>
        <tr>
          <td><?php echo "$no";?></td>
          <td><?php echo $row_rsChartGuru['tanggal']; ?></td>
          <td align="center" nowrap="nowrap"><?php $data_tanggal=date('d-m-Y', strtotime($row_rsChartGuru['tanggal'])); echo $data_tanggal; ?></td>
          <td align="center" nowrap="nowrap"><?php
  $timestamp= $row_rsChartGuru['tanggal'];
  
date_default_timezone_set('Asia/Jakarta');
  tgl_indo($jam_jalan); 
?>
            <?php echo tgl_indo($timestamp); ?></td>
          <td align="center" nowrap="nowrap"><?php echo $row_rsChartGuru['total']; ?></td>
        </tr>
        <?php } while ($row_rsChartGuru = mysql_fetch_assoc($rsChartGuru)); ?>
    </table>
      <p>&nbsp;</p>

</div>
</div>

</body>
</html>
<?php
mysql_free_result($rsChartSiswa);

mysql_free_result($rsChartGuru);
?>
