<?php 
	//include'home.php';
	include 'login.php'; 
	//include 'Templates/siakadtemplate/template.php';
?>
