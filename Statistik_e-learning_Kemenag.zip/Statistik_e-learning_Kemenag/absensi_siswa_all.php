<?php require_once('Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_database, $database);
$query_rsAbsSis = "SELECT * FROM tr_absensisiswa, tm_siswa WHERE tm_siswa.id=tr_absensisiswa.tmsiswa_id ORDER BY absen DESC";
$rsAbsSis = mysql_query($query_rsAbsSis, $database) or die(mysql_error());
$row_rsAbsSis = mysql_fetch_assoc($rsAbsSis);
$totalRows_rsAbsSis = mysql_num_rows($rsAbsSis);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Absensi Siswa Harian</title>
</head>

<body>
<p><strong>Absensi Harian Siswa. Tanggal <?php
echo date('d-m-Y H:i:s'); 
?></strong> (<a href="absensi_siswa_harian.php?tanggal=<?php echo date('Y-m-d');?>" target="_blank">Lihat Hari Ini Disini</a>)</p>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td nowrap="nowrap"><img src="images/icon60.png" width="60" height="60" /></td>
    <td align="center" nowrap="nowrap" style="font-size:1vw;">Laporan Absensi Harian Siswa<br>
      Via E-learning Kemenag<br />
      MAN 1 KOTA SUKABUMI<br />
      http://man1kotasmi.sch.id</td>
  </tr>
</table>
<table border="0" align="center"  class="table table-hover"  style="font-size:1vw;">
  <tr>
    <td align="center" bgcolor="#CCCCCC"><strong>No.</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Id.Sis</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>NISN</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>NAMA</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>KELAS</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>ROMBEL</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>T.Ajaran</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Tanggal</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Jam.Asensi</strong></td>
    <td align="center" bgcolor="#CCCCCC">Aktivitas<?php
include 'time.php';
ini_set('date.timezone', 'Asia/Jakarta');

$jam_jalan = date('Y-m-d H:i:s');

?></td>
  </tr>
  <?php $no=0; do { $no++; ?>
    <tr>
      <td align="center"><?php echo "$no";?></td>
      <td align="center"><?php echo $row_rsAbsSis['id']; ?></td>
      <td align="center"><?php echo $row_rsAbsSis['nisn']; ?></td>
      <td align="left"><?php echo $row_rsAbsSis['nama']; ?></td>
      <td align="center"><?php echo $row_rsAbsSis['kelas']; ?></td>
      <td align="center"><?php echo $row_rsAbsSis['rombel']; ?></td>
      <td align="center"><?php echo $row_rsAbsSis['ajaran']; ?></td>
      <td align="center"><strong><?php echo $row_rsAbsSis['tanggal']; ?></strong></td>
      <td align="center"><strong><?php echo $row_rsAbsSis['absen']; ?></strong></td>
      <td align="center" nowrap="nowrap"><?php
  $timestamp=$row_rsAbsSis['absen'];
date_default_timezone_set('Asia/Jakarta');
  tgl_indo($jam_jalan); 
?>
      <?php echo tgl_indo($timestamp); ?></td>
    </tr>
    <?php } while ($row_rsAbsSis = mysql_fetch_assoc($rsAbsSis)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($rsAbsSis);
?>
