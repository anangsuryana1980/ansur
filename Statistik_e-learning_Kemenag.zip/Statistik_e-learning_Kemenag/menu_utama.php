	<?php 
	if(isset($_GET['page'])){
		$page = $_GET['page'];
 
		switch ($page) {
			case 'home':
				include "home.php";
				break;
			case 'login':
				include "login.php";
			case 'guru':
				include "absensi_guru_all.php";
				break;
			case 'siswa':
				include "absensi_siswa_all.php";
				break;
			case 'statsiswa':
				include "absensi_siswa_statistik.php";
				break;
			case 'aktifitasguru':
				include "guru_aktifitas.php";
				break;
			case 'chartguruharian':
				include "chart_absensi_guru_perhari.php";
				break;
			case 'chartsiswaharian':
				include "chart_absensi_siswa_perhari.php";
				break;
			case 'gabungan':
				include "chart_absensi_guru_siswa_perhari.php";
				break;
			case 'perwalian':
				include "perwalian.php";
				break;
			case 'statistikkuliah':
				include "statistik_perkuliahan.php";
			case 'honorarium':
				include "honor_dosen.php";

				break;
			case 'absensi':
				include "absensi_perkuliahan.php";
				break;
			case 'ta':
				include "tahunajaran.php";
				break;

			case 'datadosen':
				include "datadosen.php";
				break;
			case 'datamahasiswa':
				include "datamahasiswa.php";
				break;

			case 'dosen':
				include "dosen.php";
				break;
			case 'dosenmatkul':
				include "dosen_matkul.php";
				break;
			case 'mahasiswa':
				include "mahasiswa.php";
				break;
			case 'mhskls':
				include "mahasiswa_kelas.php";
				break;
			case 'matkul':
				include "matkul.php";
				break;
			case 'matkulfinish':
				include "matkul_finish.php";
				break;
			case 'editakun':
				include "editakun.php";
				break;			
			default:
				echo "<center><h3>Maaf. Halaman tidak di temukan !</h3></center>";
				break;
		}
	}else{
		include "home.php";
	}
 
	 ?>