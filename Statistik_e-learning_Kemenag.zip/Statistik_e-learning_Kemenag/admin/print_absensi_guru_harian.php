<?php require_once('../Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rsLaporanAbsensiGuru = "-1";
if (isset($_GET['tanggal'])) {
  $colname_rsLaporanAbsensiGuru = $_GET['tanggal'];
}
mysql_select_db($database_database, $database);
$query_rsLaporanAbsensiGuru = sprintf("SELECT * FROM tr_absensi, tm_guru WHERE tanggal = %s AND tm_guru.id=tr_absensi.tmguru_id  AND tm_guru.nama ASC", GetSQLValueString($colname_rsLaporanAbsensiGuru, "date"));
$rsLaporanAbsensiGuru = mysql_query($query_rsLaporanAbsensiGuru, $database) or die(mysql_error());
$row_rsLaporanAbsensiGuru = mysql_fetch_assoc($rsLaporanAbsensiGuru);
$totalRows_rsLaporanAbsensiGuru = mysql_num_rows($rsLaporanAbsensiGuru);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td align="center"><p>&nbsp;</p>
      <table border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td nowrap="nowrap"><img src="images/icon60.png" alt="" width="60" height="60" /></td>
          <td align="center" nowrap="nowrap"><h3>Laporan Absensi Guru Harian Via E-learning Kemenag<br />
            MAN 1 KOTA SUKABUMI<br />
            Http://man1kotasmi.sch.id</h3></td>
        </tr>
      </table>
      <p><strong>Absensi Guru Harian Online Learning Tanggal :
        <?php
echo date('d-m-Y H:i:s'); 
?>
        </strong><br />
      </p></td>
  </tr>
</table>
<table border="1">
  <tr>
    <td>id</td>
    <td>id</td>
    <td>nama</td>
    <td>&nbsp;</td>
    <td>folder</td>
    <td>status</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_rsLaporanAbsensiGuru['id']; ?></td>
      <td><?php echo $row_rsLaporanAbsensiGuru['id']; ?></td>
      <td><?php echo $row_rsLaporanAbsensiGuru['nama']; ?></td>
      <td><?php echo $row_rsLaporanAbsensiGuru['tanggal']; ?></td>
      <td><?php echo $row_rsLaporanAbsensiGuru['absen']; ?></td>
      <td><?php echo $row_rsLaporanAbsensiGuru['status']; ?></td>
    </tr>
    <?php } while ($row_rsLaporanAbsensiGuru = mysql_fetch_assoc($rsLaporanAbsensiGuru)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($rsLaporanAbsensiGuru);
?>
