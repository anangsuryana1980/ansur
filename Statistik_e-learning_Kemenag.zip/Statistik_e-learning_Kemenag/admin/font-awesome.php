<?php require_once('Connections/database.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "mhs";
$MM_donotCheckaccess = "false";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && false) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "object/mahasiswa/dashboard.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_database, $database);
$query_rsAllDosen = "SELECT * FROM akun WHERE `level` = 'dosen'";
$rsAllDosen = mysql_query($query_rsAllDosen, $database) or die(mysql_error());
$row_rsAllDosen = mysql_fetch_assoc($rsAllDosen);
$totalRows_rsAllDosen = mysql_num_rows($rsAllDosen);

mysql_select_db($database_database, $database);
$query_rsAllMhs = "SELECT * FROM akun WHERE `level` = 'mhs'";
$rsAllMhs = mysql_query($query_rsAllMhs, $database) or die(mysql_error());
$row_rsAllMhs = mysql_fetch_assoc($rsAllMhs);
$totalRows_rsAllMhs = mysql_num_rows($rsAllMhs);

$colname_rsSuperAdm = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_rsSuperAdm = $_SESSION['MM_Username'];
}
mysql_select_db($database_database, $database);
$query_rsSuperAdm = sprintf("SELECT * FROM `admin` WHERE username = %s", GetSQLValueString($colname_rsSuperAdm, "text"));
$rsSuperAdm = mysql_query($query_rsSuperAdm, $database) or die(mysql_error());
$row_rsSuperAdm = mysql_fetch_assoc($rsSuperAdm);
$totalRows_rsSuperAdm = mysql_num_rows($rsSuperAdm);

$colname_rsAvatar = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_rsAvatar = $_SESSION['MM_Username'];
}
mysql_select_db($database_database, $database);
$query_rsAvatar = sprintf("SELECT * FROM  avatar, akun WHERE username = %s AND avatar.user_avatar=%s", GetSQLValueString($colname_rsAvatar, "text"),GetSQLValueString($colname_rsAvatar, "text"));
$rsAvatar = mysql_query($query_rsAvatar, $database) or die(mysql_error());
$row_rsAvatar = mysql_fetch_assoc($rsAvatar);
$totalRows_rsAvatar = mysql_num_rows($rsAvatar);

$colname_rsMhsAkun = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_rsMhsAkun = $_SESSION['MM_Username'];
}
mysql_select_db($database_database, $database);
$query_rsMhsAkun = sprintf("SELECT * FROM akun, mhs WHERE username = %s AND mhs.no_id_mhs=akun.username", GetSQLValueString($colname_rsMhsAkun, "text"));
$rsMhsAkun = mysql_query($query_rsMhsAkun, $database) or die(mysql_error());
$row_rsMhsAkun = mysql_fetch_assoc($rsMhsAkun);
$totalRows_rsMhsAkun = mysql_num_rows($rsMhsAkun);

$colname_rsMhsBio = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_rsMhsBio = $_SESSION['MM_Username'];
}
mysql_select_db($database_database, $database);
$query_rsMhsBio = sprintf("SELECT * FROM akun, mhs, kelas WHERE username = %s AND mhs.no_id_mhs=%s  AND akun.kelas=kelas.no_kls", GetSQLValueString($colname_rsMhsBio, "text"),GetSQLValueString($colname_rsMhsBio, "text"));
$rsMhsBio = mysql_query($query_rsMhsBio, $database) or die(mysql_error());
$row_rsMhsBio = mysql_fetch_assoc($rsMhsBio);
$totalRows_rsMhsBio = mysql_num_rows($rsMhsBio);
?>
<!DOCTYPE html>
<html><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Mahasiswa | Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="template/AdminLTE/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="template/AdminLTE/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="template/AdminLTE/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="template/AdminLTE/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="template/AdminLTE/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="template/AdminLTE/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="template/AdminLTE/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="template/AdminLTE/plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 <link rel="stylesheet" href="object/mahasiswa/page.css">
  <!-- Ionicons -->
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar fixed-top navbar-expand navbar-dark navbar-blue">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="object/mahasiswa/index.php?keyword=$&button=cari" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>
    </ul>
    
   

    <!-- SEARCH FORM -->
    <form class="form-inline ml-3" method="get" action="">
      <div class="input-group input-group-sm">
        <input name="keyword" id="keyword" class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->

        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
                        
            <!-- Message End -->
         
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">Lihat Semua Pesan</a>
        </div>
      </li>
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge">15</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">15 Notifikasi</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 pesan baru
            <span class="float-right text-muted text-sm">3 menit yang lalu</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-users mr-2"></i> 8 pesan dari teman
            <span class="float-right text-muted text-sm">12 jam lalu</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-file mr-2"></i> 3 new reports
            <span class="float-right text-muted text-sm">2 hari lalu</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">Lihat Semua Notifikasi</a>
        </div>
      </li>
      
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="object/mahasiswa/index.php?keyword=$&button=cari" class="brand-link">
      <img src="images/logo-staismi.png" height="50" alt="Kampus Logo" class="rounded mx-auto d-block-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">SIAKAD - MAHASISWA</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image"><a href="object/mahasiswa/index.php?page=avatarupload"><img src="avatar/<?php echo $row_rsAvatar['img_avatar']; ?>" class="img-circle elevation-2" alt="KLIK Foto!"></a></div>
        <div class="info"><a href="object/mahasiswa/index.php?page=akun_mhs" class="d-block"><?php echo $row_rsMhsBio['name_mhs']; ?></a></div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="true">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
         
          <li class="nav-item">
            <a href="object/mahasiswa/index.php?page=krsonline" class="navbar navbar-expand navbar-orange navbar-light">
              <i class="fas fa-box-open"></i>
               KRS Online
            </a>
          </li>
               
               
               
          <li class="nav-item has-treeview menu-close">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard Mahasiswa
               <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview menu-open">
              <li class="nav-item">
                <a href="object/mahasiswa/index.php?page=akun_mhs" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Edit Akun Anda</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="object/mahasiswa/index.php?page=biodata" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                <p>Edit Biodata & Identitas</p>
                </a>
              </li>
              <li class="nav-item"></li>
            </ul>
          </li>
          
          
              
          
          
          
          <li class="nav-item"></li>
          <li class="nav-item has-treeview menu-close">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Riwayat Perkuliahan
              <i class="fas fa-angle-left right"></i></p>
            </a>
            <ul class="nav nav-treeview">
            
            <li class="nav-item">
                <a href="object/mahasiswa/index.php?page=#" class="nav-link">
                  <i class="nav-icon fas fa-edit"></i>
                  <p>Mata Kuliah Selesai</p>
                </a>
              </li>         
            </ul>
          </li>
     
     
  
     
     
         
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-envelope"></i>
              <p>
                Tunggakan SPP
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Tunggakan Anda</p>
                </a>
              </li>              
            </ul>
          </li>
          
          <li class="nav-item">
            <a href="https://adminlte.io/docs/3.0" class="nav-link">
              <i class="nav-icon fas fa-file"></i>
              <p>Pengumuman</p>
            </a>
          </li>

          <li class="nav-header">Hal Lainnya</li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-danger"></i>
              <p class="text">Jadwal Kuliah</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-warning"></i>
              <p>Jadwal Ujian</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Jadwal Sidang</p>
            </a>
          </li>
                      <li class="btn btn-block bg-gradient-danger btn-xs">
            <a href="<?php echo $logoutAction ?>" class="nav-link">
              <i class="fas fa-power-off"> </i>
              <p>LOGOUT</p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="object/mahasiswa/index.php">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3>21 <sup style="font-size: 20px">SKS</sup></h3>
                 
                <p><sup style="font-size: 20px">TUJUH</sup>Mata Kuliah Berjalan</p>
              </div>
              <div class="icon">
                <i class="fas fa-tasks"></i>
              </div>
              <a href="object/mahasiswa/index.php?page=mhs" class="small-box-footer">Detail Mata Kuliah Berjalan <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo $totalRows_rsAllMhs ?> <sup style="font-size: 20px">SKS</sup></h3>

                <p><sup style="font-size: 20px">121</sup>Total Matakuliah Selesai</p>
              </div>
              <div class="icon">
                <i class="fas fa-user-graduate"></i>
              </div>
              <a href="object/mahasiswa/index.php?page=mahasiswa" class="small-box-footer">Detail Mata Kuliah Selesai <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3>24<sup style="font-size: 20px">SKS</sup></h3>

                <p><sup style="font-size: 20px">11</sup>Mata Kuliah Wajib Ujian</p>
              </div>
              <div class="icon">
                 <i class="fas fa-book-open"></i>
              </div>
              <a href="object/mahasiswa/index.php?page=matkul" class="small-box-footer">Detail Matkul <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><sup style="font-size: 20px">Rp.</sup>6.500.000</h3>

                <p>Tunggakan SPP</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="badan">
          	<?php
				include 'object/mahasiswa/menu_mhs.php'; 
			?>
          </div>
          

        <!-- /.row -->
        <!-- Main row --><!-- /.card -->
    </section>

          <!-- right col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid --><!-- /.content --><!-- /.content-wrapper -->
  <footer class="main-footer"><strong>Copyright &copy; 2020 <a href="#">SIAKAD</a>.</strong> STAI SUKABUMI.
    <div class="float-right d-none d-sm-inline-block"> <b>V</b> 1.0.0 
    </div>
.  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

<!-- ./wrapper -->

<!-- jQuery -->
<script src="template/AdminLTE/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="template/AdminLTE/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="template/AdminLTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS --><script src="template/AdminLTE/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="template/AdminLTE/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="template/AdminLTE/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="template/AdminLTE/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="template/AdminLTE/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="template/AdminLTE/plugins/moment/moment.min.js"></script>
<script src="template/AdminLTE/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="template/AdminLTE/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="template/AdminLTE/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="template/AdminLTE/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="template/AdminLTE/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="template/AdminLTE/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="template/AdminLTE/dist/js/demo.js"></script>
</body>
</html>
<?php
mysql_free_result($rsAllDosen);

mysql_free_result($rsAllMhs);

mysql_free_result($rsSuperAdm);

mysql_free_result($rsAvatar);

mysql_free_result($rsMhsAkun);

mysql_free_result($rsMhsBio);
?>
