<?php require_once('../Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_database, $database);
$query_rsChartSiswa = "SELECT tanggal, count(DISTINCT tmsiswa_id) AS total FROM tr_absensisiswa GROUP BY tanggal ORDER BY tanggal DESC";
$rsChartSiswa = mysql_query($query_rsChartSiswa, $database) or die(mysql_error());
$row_rsChartSiswa = mysql_fetch_assoc($rsChartSiswa);
$totalRows_rsChartSiswa = mysql_num_rows($rsChartSiswa);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/highcharts.js" type="text/javascript"></script>
<script type="text/javascript">
	var chart1; // globally available
$(document).ready(function() {
      chart1 = new Highcharts.Chart({
         chart: {
            renderTo: 'container',
            type: 'column'
         },   
         title: {
            text: 'Grafik Kehadiran Harian Siswa'
         },
         xAxis: {
            categories: ['Tanggal Login']
         },
         yAxis: {
            title: {
               text: 'Jumlah Login Siswa Per-Hari'
            }
         },
              series:             
            [
            <?php 
        	
           $sql   = "SELECT tanggal  FROM tr_absensisiswa GROUP BY tanggal ORDER BY tanggal ASC";
            $query = mysql_query( $sql )  or die(mysql_error());
            while( $ret = mysql_fetch_array( $query ) ){
            	$tanggal=$ret['tanggal'];                     
                 $sql_total   = "SELECT count(DISTINCT tmsiswa_id) AS total FROM tr_absensisiswa WHERE tanggal='$tanggal'";        
                 $query_total = mysql_query( $sql_total ) or die(mysql_error());
                 while( $data = mysql_fetch_array( $query_total ) ){
                    $total = $data['total'];  
					$tanggal_siswa=$data_tanggal=date('d-m-Y', strtotime($ret['tanggal']));                
                  }             
                  ?>
                  {
                      name: '<?php echo $tanggal_siswa; ?>',
                      data: [<?php echo $total; ?>]
                  },
                  <?php } ?>
            ]
      });
   });	
</script>
</head>

<body>
Kurva Login Harian Kehadiran Siswa

</head>
    <body>
    <script>
        var barchart = document.getElementById('bar-chart');
        var chart = new Chart(barchart, {
          type: 'bar',
          data: {
            labels: <?php echo json_encode($data_tanggal) ?>, // Merubah data tanggal menjadi format JSON
            datasets: [{
              label: 'Data Penjualan',
              data: <?php echo json_encode($data_total) ?>,
              backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)'
              ],
              borderColor: [
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)'
              ],
              borderWidth: 2
            }]
          }
        });

        var linechart = document.getElementById('line-chart');
        var chart = new Chart(linechart, {
          type: 'line',
          data: {
            labels: <?php echo json_encode($data_tanggal) ?>, // Merubah data tanggal menjadi format JSON
            datasets: [{
              label: 'Data Penjualan',
              data: <?php echo json_encode($data_total) ?>,
              borderColor: 'rgba(255,99,132,1)',
              backgroundColor: 'transparent',
              borderWidth: 2
            }]
          }
        });
      </script>
      
<div id='container'></div>	
      <p>&nbsp;</p><center>
        Jumlah Hari Berjalan : <strong><?php echo $totalRows_rsChartSiswa ?></strong>
      Hari
      </center>
      <table border="0" align="center" class="table table-hover"  style="font-size:1vw;">
        <tr>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>No.</strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Tanggal.Eng</strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Tanggal.Id</strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Ket.
            <?php
include 'time.php';
ini_set('date.timezone', 'Asia/Jakarta');

$jam_jalan = date('Y-m-d H:i:s');

?>
          </strong></td>
          <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Jml.Siswa/Hari</strong></td>
        </tr>
        <?php $no=0; do { $no++; ?>
        <tr>
          <td><?php echo "$no";?></td>
          <td><?php echo $row_rsChartSiswa['tanggal']; ?></td>
          <td align="center" nowrap="nowrap"><?php $data_tanggal=date('d-m-Y', strtotime($row_rsChartSiswa['tanggal'])); echo $data_tanggal; ?></td>
          <td align="center" nowrap="nowrap"><?php
  $timestamp = $row_rsChartSiswa['tanggal'];
  
date_default_timezone_set('Asia/Jakarta');
  tgl_indo($jam_jalan); 
?>            <?php echo tgl_indo($timestamp); ?></td>
          <td align="center" nowrap="nowrap"><?php echo $row_rsChartSiswa['total']; ?></td>
        </tr>
        <?php } while ($row_rsChartSiswa = mysql_fetch_assoc($rsChartSiswa)); ?>
      </table>
      <p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($rsChartSiswa);
?>
