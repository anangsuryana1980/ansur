<?php require_once('Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_rsGuru = 10;
$pageNum_rsGuru = 0;
if (isset($_GET['pageNum_rsGuru'])) {
  $pageNum_rsGuru = $_GET['pageNum_rsGuru'];
}
$startRow_rsGuru = $pageNum_rsGuru * $maxRows_rsGuru;

mysql_select_db($database_database, $database);
$query_rsGuru = "SELECT * FROM tm_guru";
$query_limit_rsGuru = sprintf("%s LIMIT %d, %d", $query_rsGuru, $startRow_rsGuru, $maxRows_rsGuru);
$rsGuru = mysql_query($query_limit_rsGuru, $database) or die(mysql_error());
$row_rsGuru = mysql_fetch_assoc($rsGuru);

if (isset($_GET['totalRows_rsGuru'])) {
  $totalRows_rsGuru = $_GET['totalRows_rsGuru'];
} else {
  $all_rsGuru = mysql_query($query_rsGuru);
  $totalRows_rsGuru = mysql_num_rows($all_rsGuru);
}
$totalPages_rsGuru = ceil($totalRows_rsGuru/$maxRows_rsGuru)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>TEST</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table border="1">
  <tr>
    <td>id</td>
    <td>nama</td>
    <td>gender</td>
    <td>pendidikan</td>
    <td>tempat</td>
    <td>tgl_lahir</td>
    <td>nuptk</td>
    <td>password</td>
    <td>tmmadrasah_id</td>
    <td>i_entry</td>
    <td>d_entry</td>
    <td>i_update</td>
    <td>d_update</td>
    <td>foto</td>
    <td>folder</td>
    <td>status</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_rsGuru['id']; ?></td>
      <td><?php echo $row_rsGuru['nama']; ?></td>
      <td><?php echo $row_rsGuru['gender']; ?></td>
      <td><?php echo $row_rsGuru['pendidikan']; ?></td>
      <td><?php echo $row_rsGuru['tempat']; ?></td>
      <td><?php echo $row_rsGuru['tgl_lahir']; ?></td>
      <td><?php echo $row_rsGuru['nuptk']; ?></td>
      <td><?php echo $row_rsGuru['password']; ?></td>
      <td><?php echo $row_rsGuru['tmmadrasah_id']; ?></td>
      <td><?php echo $row_rsGuru['i_entry']; ?></td>
      <td><?php echo $row_rsGuru['d_entry']; ?></td>
      <td><?php echo $row_rsGuru['i_update']; ?></td>
      <td><?php echo $row_rsGuru['d_update']; ?></td>
      <td><?php echo $row_rsGuru['foto']; ?></td>
      <td><?php echo $row_rsGuru['folder']; ?></td>
      <td><?php echo $row_rsGuru['status']; ?></td>
    </tr>
    <?php } while ($row_rsGuru = mysql_fetch_assoc($rsGuru)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($rsGuru);
?>
