<?php require_once('../Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rsVideoSiswa = "-1";
if (isset($_GET['keyfile'])) {
  $colname_rsVideoSiswa = $_GET['keyfile'];
}
mysql_select_db($database_database, $database);
$query_rsVideoSiswa = sprintf("SELECT * FROM tr_keterampilannilai, tr_keterampilan, tr_kelas, tm_mapel WHERE `file` LIKE %s AND tr_keterampilan.id=tr_keterampilannilai.trketerampilan_id AND tr_keterampilan.trkelas_id=tr_kelas.id AND tr_kelas.tmmapel_id=tm_mapel.id ORDER BY tr_keterampilannilai.tanggal DESC", GetSQLValueString("%" . $colname_rsVideoSiswa . "%", "text"));
$rsVideoSiswa = mysql_query($query_rsVideoSiswa, $database) or die(mysql_error());
$row_rsVideoSiswa = mysql_fetch_assoc($rsVideoSiswa);
$totalRows_rsVideoSiswa = mysql_num_rows($rsVideoSiswa);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>File Video Siswa dan Guru:</p><form id="formSearch" name="formSearch" method="get" action="dashboard.php?page=video">
  <table border="0" align="left" cellpadding="0" cellspacing="0">
    <tr>
      <td>MP4</td>
      <td><input type=class="form-control""text" name="keyfile" id="keyfile" class="form-control"/></td>
      <td align="left">&nbsp;</td>
      <td><a href="dashboard.php?page=video">
        <button onclick="submit" type="submit" class="btn btn-primary" id="cari">  Cari </button>
      </a></td>
    </tr>
  </table>
</form></p>
<p>&nbsp;</p>
<p><a href="dashboard.php?page=nilaisiswa">Nilai Video</a> | Tugas Video
</p>
<table width="100%" border="0" align="left" class="table table-hover"  style="font-size:1vw;">
    <tr>
      <td colspan="5">Penilaian Keterampilan Siswa : <strong><?php echo $totalRows_rsVideoSiswa ?></strong></td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td align="center"><strong>id</strong></td>
      <td align="center"><strong>Sis</strong></td>
      <td align="center"><strong>Tgl.Mulai</strong></td>
      <td align="center"><strong>Tgl.Selesai</strong></td>
      <td align="center"><strong>ktrmpln</strong></td>
      <td align="center"><strong>nilai</strong></td>
      <td align="center"><strong>folder</strong></td>
      <td align="center"><strong>file</strong></td>
      <td align="center"><strong>nama</strong></td>
    </tr>
    <?php do { ?>
      <tr>
        <td><?php echo $row_rsVideoSiswa['id']; ?></td>
        <td><?php echo $row_rsVideoSiswa['tmsiswa_id']; ?></td>
        <td><?php echo $row_rsVideoSiswa['tgl_mulai']; ?></td>
        <td><?php echo $row_rsVideoSiswa['tgl_selesai']; ?></td>
        <td><?php echo $row_rsVideoSiswa['trketerampilan_id']; ?></td>
        <td><?php echo $row_rsVideoSiswa['nilai']; ?></td>
        <td><?php echo $row_rsVideoSiswa['folder']; ?></td>
        <td><?php echo $row_rsVideoSiswa['file']; ?></td>
        <td><?php echo $row_rsVideoSiswa['nama']; ?></td>
      </tr>
      <?php } while ($row_rsVideoSiswa = mysql_fetch_assoc($rsVideoSiswa)); ?>
  </table>
</body>
</html>
<?php
mysql_free_result($rsVideoSiswa);
?>
