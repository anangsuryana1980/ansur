<?php require_once('../Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rsNilaiSis = "-1";
if (isset($_SERVER['keyword'])) {
  $colname_rsNilaiSis = $_SERVER['keyword'];
}
mysql_select_db($database_database, $database);
$query_rsNilaiSis = sprintf("SELECT * FROM tr_nilai WHERE `file` LIKE %s ORDER BY tanggal DESC", GetSQLValueString("%" . $colname_rsNilaiSis . "%", "text"));
$rsNilaiSis = mysql_query($query_rsNilaiSis, $database) or die(mysql_error());
$row_rsNilaiSis = mysql_fetch_assoc($rsNilaiSis);
$totalRows_rsNilaiSis = mysql_num_rows($rsNilaiSis);
$query_rsNilaiSis = "SELECT * FROM tr_nilai WHERE tr_nilai.`file`LIKE '.mp4' ORDER BY tanggal DESC";
$rsNilaiSis = mysql_query($query_rsNilaiSis, $database) or die(mysql_error());
$row_rsNilaiSis = mysql_fetch_assoc($rsNilaiSis);
$totalRows_rsNilaiSis = mysql_num_rows($rsNilaiSis);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Nilai Siswa</title>
</head>

<body>
<p>Nilai Siswa</p>
<form id="form1" name="form1" method="get" action="dashboard.php?page=nilaisiswa">
  <table border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td>MP4</td>
      <td><input type="text" name="keyword" id="keyword" /></td>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Cari" /></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<p><a href="dashboard.php?page=nilaisiswa">Nilai Video</a> | <a href="?page=video">Tugas Video</a> | </p>
<table border="1">
  <tr>
    <td>id</td>
    <td>tmsiswa_id</td>
    <td>trtugas_id</td>
    <td>trujian_id</td>
    <td>nilai</td>
    <td>remedial</td>
    <td>folder</td>
    <td>file</td>
    <td>tanggal</td>
    <td>keterangan</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_rsNilaiSis['id']; ?></td>
      <td><?php echo $row_rsNilaiSis['tmsiswa_id']; ?></td>
      <td><?php echo $row_rsNilaiSis['trtugas_id']; ?></td>
      <td><?php echo $row_rsNilaiSis['trujian_id']; ?></td>
      <td><?php echo $row_rsNilaiSis['nilai']; ?></td>
      <td><?php echo $row_rsNilaiSis['remedial']; ?></td>
      <td><?php echo $row_rsNilaiSis['folder']; ?></td>
      <td><?php echo $row_rsNilaiSis['file']; ?></td>
      <td><?php echo $row_rsNilaiSis['tanggal']; ?></td>
      <td><?php echo $row_rsNilaiSis['keterangan']; ?></td>
    </tr>
    <?php } while ($row_rsNilaiSis = mysql_fetch_assoc($rsNilaiSis)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($rsNilaiSis);
?>
