<?php require_once('../Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_rsAbsSis = 934;
$pageNum_rsAbsSis = 0;
if (isset($_GET['pageNum_rsAbsSis'])) {
  $pageNum_rsAbsSis = $_GET['pageNum_rsAbsSis'];
}
$startRow_rsAbsSis = $pageNum_rsAbsSis * $maxRows_rsAbsSis;

$sekarang_rsAbsSis = "1";
if (isset($_GET['tanggal'])) {
  $sekarang_rsAbsSis = $_GET['tanggal'];
}
mysql_select_db($database_database, $database);
$query_rsAbsSis = sprintf("SELECT * FROM tr_absensisiswa, tm_siswa WHERE tanggal=%s AND tr_absensisiswa.tmsiswa_id=tm_siswa.id GROUP BY tm_siswa.nisn ORDER BY tm_siswa.rombel ASC", GetSQLValueString($sekarang_rsAbsSis, "text"));
$query_limit_rsAbsSis = sprintf("%s LIMIT %d, %d", $query_rsAbsSis, $startRow_rsAbsSis, $maxRows_rsAbsSis);
$rsAbsSis = mysql_query($query_limit_rsAbsSis, $database) or die(mysql_error());
$row_rsAbsSis = mysql_fetch_assoc($rsAbsSis);

if (isset($_GET['totalRows_rsAbsSis'])) {
  $totalRows_rsAbsSis = $_GET['totalRows_rsAbsSis'];
} else {
  $all_rsAbsSis = mysql_query($query_rsAbsSis);
  $totalRows_rsAbsSis = mysql_num_rows($all_rsAbsSis);
}
$totalPages_rsAbsSis = ceil($totalRows_rsAbsSis/$maxRows_rsAbsSis)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Absensi Siswa Harian</title>
</head>

<body>
<p><strong>Absensi Harian Siswa. Tanggal <?php
echo date('d-m-Y H:i:s'); 
?></strong></p>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td nowrap="nowrap"><img src="images/icon60.png" width="60" height="60" /></td>
    <td align="center" nowrap="nowrap"><h3>Laporan Absensi Harian Siswa<br>
      Via E-learning Kemenag<br />
        MAN 1 KOTA SUKABUMI<br />
      http://man1kotasmi.sch.id</h3></td>
  </tr>
</table><br><center>
Jumlah : <strong><?php echo $totalRows_rsAbsSis ?> Siswa</strong></center>
<table border="1" align="center"  class="table table-hover"  style="font-size:1vw;">
  <tr>
    <td align="center" bgcolor="#CCCCCC"><strong>id</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Id</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>NISN</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>NAMA</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>KELAS</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>ROMBEL</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>T.Ajaran</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Tanggal</strong></td>
    <td align="center" bgcolor="#CCCCCC"><strong>Jam.Asensi</strong></td>
  </tr>
  <?php $no=0; do { $no++; ?>
    <tr>
      <td align="center"><?php echo "$no";?></td>
      <td align="center"><?php echo $row_rsAbsSis['id']; ?></td>
      <td align="center"><?php echo $row_rsAbsSis['nisn']; ?></td>
      <td align="left"><?php echo $row_rsAbsSis['nama']; ?></td>
      <td align="center"><?php echo $row_rsAbsSis['kelas']; ?></td>
      <td align="center"><?php echo $row_rsAbsSis['rombel']; ?></td>
      <td align="center"><?php echo $row_rsAbsSis['ajaran']; ?></td>
      <td align="center"><strong><?php echo $row_rsAbsSis['tanggal']; ?></strong></td>
      <td align="center"><strong><?php echo $row_rsAbsSis['absen']; ?></strong></td>
    </tr>
    <?php } while ($row_rsAbsSis = mysql_fetch_assoc($rsAbsSis)); ?>
</table>
<script>
       window.print();
    </script> 
</body>
</html>
<?php
mysql_free_result($rsAbsSis);
?>
