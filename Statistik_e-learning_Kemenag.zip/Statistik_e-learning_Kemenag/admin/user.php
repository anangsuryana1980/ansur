<?php require_once('Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=md5($_POST['password']);
  $MM_fldUserAuthorization = "level";
  $MM_redirectLoginSuccess = "guru/dashboard.php";
  $MM_redirectLoginFailed = "forgot_password.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_database, $database);
  	
  $LoginRS__query=sprintf("SELECT username_guru, password_guru, level FROM user_guru WHERE username_guru=%s AND password_guru=%s",
  GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $database) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
    
    $loginStrGroup  = mysql_result($LoginRS,0,'level');
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<head>

	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta name="author" content="AnGs Smi">
	<title>SIMKU-MANISI | MAN 1 KOTA SUKABUMI</title>
    <link rel="shortcut icon" href="images/icon60.png">
    <link rel="stylesheet" href="script/css/login.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    

</head>
<body>
	<div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
    <div class="card card0 border-0">
        <div class="row d-flex">
            <div class="col-lg-6">
                <div class="card1 pb-5">
                     <div class="row px-3 justify-content-center mt-4 mb-5 border-line"> <a style="cursor: pointer;" onClick="location.href='index.php'"><img src="images/logo-simkumanisi.png" target="_parent" class="logo"></a></div>
                    <div class="d-none d-lg-block">
                     <div class="row px-3 justify-content-center mt-4 mb-5 border-line"><a href="#"><a href="#"><img src="images/manisi-image.png" class="image"></a>
                     </div>
                  </div>
                  </div>
           		 </div>
                 
                 
            
            
            
            
<div class="col-lg-6">
<form action="<?php echo $loginFormAction; ?>" method="POST" name="formLogin" id="formLogin">
                
                <div class="card2 card border-0 px-4 py-5">
                <div class="row mb-0 px-3">
                <h5 style="font-size: 2vw;" class="mb-0 mr-3 mt-2"><i class='fas fa-users'></i> Login Wali Kelas &amp; Siswa</h5></div>
<p>TES</p>
<div class="row px-3">
                      <h6 class="mb-0 text-sm"><i class="fas fa-user"></i>  Username </h6>
                        </label> <input class="fas fa-key" type="text" name="username" placeholder="Ketik NISN/NUPTK" id="username"> </div>
<div class="row px-3"> <label class="mb-1">
                            <h6 class="mb-0 text-sm"><i class="fas fa-key"></i> Password</h6>
                        </label> <input class="fas fa-key" type="password" name="password" placeholder="Ketik Password"> </div>
<div class="row px-3 mb-4">
                        <div class="custom-control custom-checkbox custom-control-inline"> <input id="chk1" type="checkbox" name="chk" class="custom-control-input"> <label for="chk1" class="custom-control-label text-sm">Remember me</label> </div> 
                        <span style="cursor: pointer;" onclick = window.open('forgot_password.php'); class="ml-auto mb-0 text-sm" >Lupa  Password?</span>
</div>
                  <div class="row mb-3 px-3"> <button type="submit" class="bg-success"><i class='fas fa-sign-in-alt'></i> L o g i n </button> </form>
                 <span style="cursor: pointer;" onclick = window.open('https://api.whatsapp.com/send?phone=6281646904430&text=Salam%20Admin%20SIMKU%20MANISI%20Saya%20Lupa%20Akun'); class="ml-auto mb-0 text-sm" ><span class="alert-warning"><i class="fab fa-whatsapp-square"></i> Hubungi Administrator !</span></span></div>
                 
 
<div class="ml-auto mb-0 text-sm">
                   <h6 style="font-size:1.2vw;"><small class="sm-1 sm-sm-1 mb-1">
                   </small><i class='fas fa-home'></i> Alamat : <br><a href="#" target="_blank">MAN 1 KOTA  SUKABUMI</a><br>Jalan Pramuka No.04 Kel.Gedongpanjang <br>Kec.Citamiang Sukabumi, Jawa Barat.<br>Phone: (0266) 227354 Fax: 0266-227354<br>Email: simku@man1kotasmi.sch.id</small></h6>
</div>
                <small class="sm-1 sm-sm-1 mb-1"><strong> <a href="#"><i class="fa fa-download"></i> Apk-Download</a></strong></small>
</div>            
</div>
</div>
       
        <div class="bg-success py-1">
            <div class="row px-4"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy; 2020.SIMKU | MAN 1 KOTA SUKABUMI</small> 
             <div class="social-contact ml-5 ml-sm-auto"><a style="font-size: 0.7vw;" href="http://facebook.com/anangsuryana2" target="_blank">Was developed <i class="fab fa-facebook-square"></i> <span>by Mee  </span></a>
             </div>
            </div>
        </div>
</body>