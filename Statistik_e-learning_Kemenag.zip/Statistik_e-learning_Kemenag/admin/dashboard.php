<?php require_once('../Connections/database.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../logout.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "login.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_database, $database);
$query_rsAbsensiGuru = "SELECT * FROM tr_absensi";
$rsAbsensiGuru = mysql_query($query_rsAbsensiGuru, $database) or die(mysql_error());
$row_rsAbsensiGuru = mysql_fetch_assoc($rsAbsensiGuru);
$totalRows_rsAbsensiGuru = mysql_num_rows($rsAbsensiGuru);

mysql_select_db($database_database, $database);
$query_rsSiswaTotal = "SELECT * FROM tm_siswa";
$rsSiswaTotal = mysql_query($query_rsSiswaTotal, $database) or die(mysql_error());
$row_rsSiswaTotal = mysql_fetch_assoc($rsSiswaTotal);
$totalRows_rsSiswaTotal = mysql_num_rows($rsSiswaTotal);

mysql_select_db($database_database, $database);
$query_rsGuruTotal = "SELECT * FROM tm_guru ORDER BY id ASC";
$rsGuruTotal = mysql_query($query_rsGuruTotal, $database) or die(mysql_error());
$row_rsGuruTotal = mysql_fetch_assoc($rsGuruTotal);
$totalRows_rsGuruTotal = mysql_num_rows($rsGuruTotal);
?>
<!DOCTYPE html>
<html><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>ADMIN | MANISI</title>
  <link rel="shortcut icon" href="../images/icon60.png">
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../template/AdminLTE/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="../template/AdminLTE/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../template/AdminLTE/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="../template/AdminLTE/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../template/AdminLTE/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="../template/AdminLTE/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="../template/AdminLTE/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../template/AdminLTE/plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 <link rel="stylesheet" href="../object/dosen/page.css">
  <!-- Ionicons -->
  <!--Tooltips LOADING.. dibawah ini-->
  
</head>
<body class="hold-transition sidebar-mini layout-fixed">

<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar fixed-top navbar-expand navbar-dark navbar-green">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="dashboard.php?keyword=$&button=cari" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a class="nav-link" data-toggle="tooltip" data-placement="bottom" title="Kontak Kampus" href="#">Contact</a>
      </li>
    </ul>
    
   

    <!-- SEARCH FORM -->
    <form class="form-inline ml-3" method="get" action="">
      <div class="input-group input-group-sm">
        <input name="keyword" id="keyword" class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fas fa-search"></i>
          </button>
        </div>
      </div>
    </form>

  <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      

        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
                        
            <!-- Message End -->
         
          <div class="dropdown-divider"></div>
          <a href="dashboard.php?page=siswa" class="dropdown-item dropdown-footer">Lihat Semua Pesan</a>
        </div>
      </li>
     
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge"> <?php echo $totalRows_rsAbsensiGuru ?> </span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header"><?php echo $totalRows_rsAbsensiGuru ?> Notifikasi</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-envelope mr-2"></i> 4 pesan baru
            <span class="float-right text-muted text-sm">3 menit yang lalu</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-file mr-2"></i> 3 new reports
            <span class="float-right text-muted text-sm">2 hari lalu</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">Lihat Semua Notifikasi</a>
        </div>
      </li>
      
      
       <li style="font-size:1.2vw;" class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="fas fa-user-graduate"></i> <span class="badge badge-warning navbar-badge"></span>
          <i class="upper fas fa-angle-down"> </i>
        </a>
        
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">
          <div class="image" >
          <a title="Detail Identitas" href="login.php"><img alt="Login Admin" height="100" class="img-circle elevation-4" hight="100" /></a>
          </div>
          </span>
          <div class="bg-gradient-success dropdown-divider">Mee</div>
          <a href="../logout.php" class="dropdown-item" data-toggle="tooltip" data-placement="bottom"  data-html="true" title="Keluar Sekarang">
            <i class="fas fa-power-off"></i> L O G  O U T
            <span class="float-right text-muted text-sm">Ya..!   <i class="left fas fa-angle-right"> </i></span>
          </a>
         </div>
         <!-- Keluar -->
         
       </li>
      
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-light-success elevation-4">
    <!-- Brand Logo -->
    <a href="dashboard.php?keyword=$&button=cari" class="brand-link">
      <img src="../images/icon60.png" height="60" alt="Kampus Logo" class="rounded mx-auto d-block-3"
           style="opacity: .8">
      <span class="brand-text font-weight-dark">e-Learn | MANISI</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image"><a href="dashboard.php"><a href="dashboard.php"><img class="img-circle elevation-2" alt="Foto"></a></div>
        <div class="info">
          <a style="font-size:1.2vw;" href="dashboard.php" class="d-block"></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="true" font="10">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard Sekolah
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="dashboard.php?page=login" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Edit Akun Guru</p>
                </a>
              </li>
           </ul>
          </li>
          
          
              
          
          
          
          <li class="nav-item"></li>
          <li class="nav-item has-treeview menu-close">
            <a href="dashboard.php?page=home" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Login Kehadiran
            <i class="fas fa-angle-left right"></i></p>
            </a>
            <ul class="nav nav-treeview">
            
            <li class="nav-item">
                <a href="dashboard.php?page=guru" class="nav-link">
                  <i class="nav-icon fas fa-edit"></i>
                  <p>History Login Guru</p>
                </a>
              </li> 
            </ul>
            <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="dashboard.php?page=chartguruharian" class="nav-link">
                  <i class="nav-icon fas fa-chart-bar"></i>
                  <p>Grafik Login Guru</p>
                </a>
              </li> 
            </ul>
           
            <ul class="nav nav-treeview">
            
            <li class="nav-item">
                <a href="dashboard.php?page=siswa" class="nav-link">
                  <i class="nav-icon fas fa-edit"></i>
                  <p>History Login Siswa</p>
                </a>
              </li> 
            </ul>
             <ul class="nav nav-treeview">
            <li class="nav-item">
                <a href="dashboard.php?page=chartsiswaharian" class="nav-link">
                  <i class="nav-icon fas fa-chart-bar"></i>
                  <p>Grafik Login Siswa</p>
                </a>
              </li> 
            </ul>
          </li>
     
     
          
          <li class="nav-item">
            <a href="https://man1kotasmi.sch.id/manager.php" target="_blank" class="nav-link">
              <i class="nav-icon fas fa-file"></i>
              <p>FileManager e-Learning</p>
            </a>
          </li>

          <li class="nav-header">Hal Lainnya</li>
          <li class="nav-item">
            <a href="dashboard.php?page=statsiswa" class="nav-link">
              <i class="nav-icon far fa-circle text-danger"></i>
              <p class="text">Aktifitas Kelas</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="dashboard.php?page=aktifitasguru" class="nav-link">
              <i class="nav-icon far fa-circle text-warning"></i>
              <p>Aktifitas Guru</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="dashboard.php?page=jadwal" class="nav-link">
              <i class="nav-icon far fa-circle text-info"></i>
              <p>Jadwal Pelajaran</p>
            </a>
          </li>
          <li class="nav-item">
            <a href="../bw/index.php" target="_blank" class="nav-link">
              <i class="nav-icon  fas fa-chart-pie text-info"></i>
              <p>Kesehatan Server</p>
            </a>
          </li>
                      <li class="btn btn-block bg-gradient-success btn-xs">
            <a href="<?php echo $logoutAction ?>" class="nav-link">
              <i class="fas fa-power-off"> </i>
              <p>MAN 1 KOTA SUKABUMI</p>
            </a>
          </li>
          <li class="btn btn-block bg-gradient btn-xs">
            <a href="#" class="nav-link"></a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
              <li class="breadcrumb-item active">Admin</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3> <?php echo $totalRows_rsSiswaTotal ?> <sup style="font-size: 15px">Total Siswa</sup></h3>
              </div>
              <div class="icon">
               <i class="fas fa-graduation-cap"></i>
              </div>
              <a href="dashboard.php?page=chartsiswaharian" class="small-box-footer">Detail Siswa <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3> <?php echo $totalRows_rsGuruTotal ?> <sup style="font-size: 20px"> Total Guru</sup></h3>

                </div>
              <div class="icon">
                <i class="fas fa-user-graduate"></i>
              </div>
              <a href="dashboard.php?page=chartguruharian" class="small-box-footer">Detail Guru <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
               <h3 style="font-size: 20px"><sup style="font-size: 20px">TT.</sup>00</h3>

                
              </div>
              <div class="icon">
                 <i class="fas fa-book-open"></i>
              </div>
              
              <a href="dashboard.php?page=statsiswa" class="small-box-footer">Detail Lengkap <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
              <h3 style="font-size: 20px"><sup style="font-size: 20px">OO.</sup>1</h3>
                
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="dashboard.php?page=video" class="small-box-footer">Detail MP4 <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
         
          <div style="font-size:1.8vw;" class="badan">
          
          
          	<?php
				include 'menu_admin.php'; 
			?>
           
          </div>
       
 
        <!-- /.row -->
        <!-- Main row --><!-- /.card -->
    </section>

          <!-- right col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid --><!-- /.content --><!-- /.content-wrapper -->
  <footer class="main-footer"><strong> &copy; 2020 <a href="#">e-Learn</a>.</strong> MAN 1 KOTA SUKABUMI
    <div class="float-right d-none d-sm-inline-block"> <b>V</b>1.0 
    </div>
.  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

<!-- ./wrapper -->

<!-- jQuery -->
<script src="../template/AdminLTE/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="../template/AdminLTE/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="../template/AdminLTE/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS --><script src="../template/AdminLTE/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="../template/AdminLTE/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="../template/AdminLTE/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="../template/AdminLTE/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="../template/AdminLTE/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="../template/AdminLTE/plugins/moment/moment.min.js"></script>
<script src="../template/AdminLTE/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="../template/AdminLTE/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="../template/AdminLTE/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="../template/AdminLTE/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="../template/AdminLTE/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../template/AdminLTE/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../template/AdminLTE/dist/js/demo.js"></script>

<!--TOOLTIPS
<script src="../../script/scriptLTE/plugins/popper/popper.js"></script>


<script src="../../script/scriptLTE/plugins/bootstrap/js/bootstrap.js"></script>
<script>
 
		$(function () {
			$('[data-toggle="tooltip"]').tooltip();
		});
 
	</script>
-->

</body>
</html>
<?php
mysql_free_result($rsAbsensiGuru);

mysql_free_result($rsSiswaTotal);

mysql_free_result($rsGuruTotal);
?>
