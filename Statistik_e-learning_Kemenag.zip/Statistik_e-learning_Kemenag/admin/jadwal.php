<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Jadwal Ganjil 2020</title>
</head>

<body>
<center>
  <strong>Jadwal Pelajaran Semester Ganjil TP. 2020/2021</strong>
</center>
<embed width="1020" height="750" src="jadwal-ganjil2020.pdf" type="application/pdf"></embed>
</body>
</html>