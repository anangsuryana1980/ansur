<?php require_once('../Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rsBahanAjar = "-1";
if (isset($_GET['keyword'])) {
  $colname_rsBahanAjar = $_GET['keyword'];
}
mysql_select_db($database_database, $database);
$query_rsBahanAjar = sprintf("SELECT * FROM tr_bahanajar WHERE bahanajar LIKE %s ORDER BY tanggal DESC", GetSQLValueString("%" . $colname_rsBahanAjar . "%", "text"));
$rsBahanAjar = mysql_query($query_rsBahanAjar, $database) or die(mysql_error());
$row_rsBahanAjar = mysql_fetch_assoc($rsBahanAjar);
$totalRows_rsBahanAjar = mysql_num_rows($rsBahanAjar);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>Bahan Ajar Guru = <strong><?php echo $totalRows_rsBahanAjar ?></strong> Video</p>
<form id="formSearch" name="formSearch" method="get" action="dashboard.php?page=bahanajar">
  <table border="0" align="left" cellpadding="0" cellspacing="0">
    <tr>
      <td>MP4</td>
      <td><input type=class="form-control""text" name="keyword" id="keyword" class="form-control"/></td>
      <td align="left">&nbsp;</td>
      <td><button onclick="submit" type="submit" class="btn btn-primary" id="cari"><i class='fas fa-search'> </i> Cari </button></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<h5><a href="?page=nilaisiswa">Nilai Video</a> | <a href="?page=video">Tugas Video</a> |</h5>
<h5>Bahan Ajar Video oleh Guru Kelas</h5>
<table width="70%" border="1""  style="font-size:1vw;" table-hover>
  <tr>
    <td align="center" nowrap="nowrap" bgcolor="#DDDDDD"><strong>id</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#DDDDDD"><strong>trkelas_id</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#DDDDDD"><strong>tragenda_id</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#DDDDDD"><strong>trrpp_id</strong></td>
    <td align="center" bgcolor="#DDDDDD"><strong>bahanajar</strong></td>
    <td align="center" bgcolor="#DDDDDD"><strong>jenis</strong></td>
    <td align="center" bgcolor="#DDDDDD"><strong>tanggal</strong></td>
    <td align="center" bgcolor="#DDDDDD"><strong>keterangan</strong></td>
    <td align="center" bgcolor="#DDDDDD"><strong>nama</strong></td>
    <td align="center" bgcolor="#DDDDDD"><strong>share</strong></td>
    <td align="center" bgcolor="#DDDDDD"><strong>folder</strong></td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_rsBahanAjar['id']; ?></td>
      <td><?php echo $row_rsBahanAjar['trkelas_id']; ?></td>
      <td><?php echo $row_rsBahanAjar['tragenda_id']; ?></td>
      <td><?php echo $row_rsBahanAjar['trrpp_id']; ?></td>
      <td><?php echo $row_rsBahanAjar['bahanajar']; ?></td>
      <td><?php echo $row_rsBahanAjar['jenis']; ?></td>
      <td><?php echo $row_rsBahanAjar['tanggal']; ?></td>
      <td><?php echo $row_rsBahanAjar['keterangan']; ?></td>
      <td><?php echo $row_rsBahanAjar['nama']; ?></td>
      <td><?php echo $row_rsBahanAjar['share']; ?></td>
      <td><?php echo $row_rsBahanAjar['folder']; ?></td>
    </tr>
    <?php } while ($row_rsBahanAjar = mysql_fetch_assoc($rsBahanAjar)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($rsBahanAjar);
?>
