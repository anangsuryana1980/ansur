<?php require_once('../Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_rsAbsSis = 1;
$pageNum_rsAbsSis = 0;
if (isset($_GET['pageNum_rsAbsSis'])) {
  $pageNum_rsAbsSis = $_GET['pageNum_rsAbsSis'];
}
$startRow_rsAbsSis = $pageNum_rsAbsSis * $maxRows_rsAbsSis;

mysql_select_db($database_database, $database);
$query_rsAbsSis = "SELECT * FROM tr_absensisiswa, tm_siswa WHERE tm_siswa.id=tr_absensisiswa.tmsiswa_id ORDER BY absen DESC";
$query_limit_rsAbsSis = sprintf("%s LIMIT %d, %d", $query_rsAbsSis, $startRow_rsAbsSis, $maxRows_rsAbsSis);
$rsAbsSis = mysql_query($query_limit_rsAbsSis, $database) or die(mysql_error());
$row_rsAbsSis = mysql_fetch_assoc($rsAbsSis);

if (isset($_GET['totalRows_rsAbsSis'])) {
  $totalRows_rsAbsSis = $_GET['totalRows_rsAbsSis'];
} else {
  $all_rsAbsSis = mysql_query($query_rsAbsSis);
  $totalRows_rsAbsSis = mysql_num_rows($all_rsAbsSis);
}
$totalPages_rsAbsSis = ceil($totalRows_rsAbsSis/$maxRows_rsAbsSis)-1;

$maxRows_rsStatistiksiswa = 1000;
$pageNum_rsStatistiksiswa = 0;
if (isset($_GET['pageNum_rsStatistiksiswa'])) {
  $pageNum_rsStatistiksiswa = $_GET['pageNum_rsStatistiksiswa'];
}
$startRow_rsStatistiksiswa = $pageNum_rsStatistiksiswa * $maxRows_rsStatistiksiswa;

mysql_select_db($database_database, $database);
$query_rsStatistiksiswa = "SELECT * FROM aktifitaskelas, tm_siswa, tr_kelas, tm_mapel WHERE tm_siswa.id=aktifitaskelas.tmsiswa_id AND tr_kelas.id=aktifitaskelas.trkelas_id AND tm_mapel.id=tr_kelas.tmmapel_id ORDER BY aktifitaskelas.tanggal DESC";
$query_limit_rsStatistiksiswa = sprintf("%s LIMIT %d, %d", $query_rsStatistiksiswa, $startRow_rsStatistiksiswa, $maxRows_rsStatistiksiswa);
$rsStatistiksiswa = mysql_query($query_limit_rsStatistiksiswa, $database) or die(mysql_error());
$row_rsStatistiksiswa = mysql_fetch_assoc($rsStatistiksiswa);

if (isset($_GET['totalRows_rsStatistiksiswa'])) {
  $totalRows_rsStatistiksiswa = $_GET['totalRows_rsStatistiksiswa'];
} else {
  $all_rsStatistiksiswa = mysql_query($query_rsStatistiksiswa);
  $totalRows_rsStatistiksiswa = mysql_num_rows($all_rsStatistiksiswa);
}
$totalPages_rsStatistiksiswa = ceil($totalRows_rsStatistiksiswa/$maxRows_rsStatistiksiswa)-1;

$queryString_rsAbsSis = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsAbsSis") == false && 
        stristr($param, "totalRows_rsAbsSis") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsAbsSis = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsAbsSis = sprintf("&totalRows_rsAbsSis=%d%s", $totalRows_rsAbsSis, $queryString_rsAbsSis);

$queryString_rsStatistiksiswa = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsStatistiksiswa") == false && 
        stristr($param, "totalRows_rsStatistiksiswa") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsStatistiksiswa = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsStatistiksiswa = sprintf("&totalRows_rsStatistiksiswa=%d%s", $totalRows_rsStatistiksiswa, $queryString_rsStatistiksiswa);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Aktifitas Kelas</title>
</head>

<body>
<p><strong>Aktifitas Kelas Mata Pelajaran. Tanggal <?php
echo date('d-m-Y H:i:s'); 
?></strong> (<a href="absensi_siswa_harian.php?tanggal=<?php echo date('Y-m-d');?>" target="_blank">Lihat Hari Ini Disini</a>)</p>
<table border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td nowrap="nowrap"><img src="images/icon60.png" width="60" height="60" /></td>
    <td align="center" nowrap="nowrap" style="font-size:1vw;">Laporan Absensi Harian Siswa<br>
      Via E-learning Kemenag<br />
      MAN 1 KOTA SUKABUMI<br />
      http://man1kotasmi.sch.id</td>
  </tr>
</table>
<p><table border="0">
  <tr>
    <td><?php if ($pageNum_rsStatistiksiswa > 0) { // Show if not first page ?>
          <a href="<?php printf("%s?pageNum_rsStatistiksiswa=%d%s", $currentPage, 0, $queryString_rsStatistiksiswa); ?>">First</a>
<?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_rsStatistiksiswa > 0) { // Show if not first page ?>
          <a href="<?php printf("%s?pageNum_rsStatistiksiswa=%d%s", $currentPage, max(0, $pageNum_rsStatistiksiswa - 1), $queryString_rsStatistiksiswa); ?>">Previous</a>
<?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_rsStatistiksiswa < $totalPages_rsStatistiksiswa) { // Show if not last page ?>
          <a href="<?php printf("%s?pageNum_rsStatistiksiswa=%d%s", $currentPage, min($totalPages_rsStatistiksiswa, $pageNum_rsStatistiksiswa + 1), $queryString_rsStatistiksiswa); ?>">Next</a>
<?php } // Show if not last page ?></td>
    <td><?php if ($pageNum_rsStatistiksiswa < $totalPages_rsStatistiksiswa) { // Show if not last page ?>
          <a href="<?php printf("%s?pageNum_rsStatistiksiswa=%d%s", $currentPage, $totalPages_rsStatistiksiswa, $queryString_rsStatistiksiswa); ?>">Last</a>
<?php } // Show if not last page ?></td>
  </tr>
</table>
</p>
<table border="0" class="table table-hover"  style="font-size:1vw;">
  <tr>
    <td align="center" nowrap="nowrap"><strong>No.</strong></td>
    <td align="center" nowrap="nowrap"><strong>Mata Pelajaran</strong></td>
    <td align="center" nowrap="nowrap"><strong>Id.Sis</strong></td>
    <td align="center" nowrap="nowrap"><strong>Ket.
      <?php
include 'time.php';
ini_set('date.timezone', 'Asia/Jakarta');

$jam_jalan = date('Y-m-d H:i:s');

?>
    </strong></td>
    <td align="center" nowrap="nowrap"><strong>Tanggal</strong></td>
    <td nowrap="nowrap"><strong>Keterangan</strong></td>
  </tr>
  <?php $no=0; do { $no++; ?>
    <tr>
      <td nowrap="nowrap"><?php echo "$no";?></td>
      <td nowrap="nowrap"><?php echo $row_rsStatistiksiswa['nama']; ?></td>
      <td nowrap="nowrap"><?php echo $row_rsStatistiksiswa['tmsiswa_id']; ?></td>
      <td align="center" nowrap="nowrap"><?php
  $timestamp=$row_rsStatistiksiswa['tanggal'];
  
date_default_timezone_set('Asia/Jakarta');
  tgl_indo($jam_jalan); 
?>
        <?php echo tgl_indo($timestamp); ?></td>
      <td nowrap="nowrap"><?php echo $row_rsStatistiksiswa['tanggal']; ?></td>
      <td><?php echo $row_rsStatistiksiswa['keterangan']; ?></td>
    </tr>
    <?php } while ($row_rsStatistiksiswa = mysql_fetch_assoc($rsStatistiksiswa)); ?>
</table>
<table border="0">
  <tr>
    <td><?php if ($pageNum_rsStatistiksiswa > 0) { // Show if not first page ?>
      <a href="<?php printf("%s?pageNum_rsStatistiksiswa=%d%s", $currentPage, 0, $queryString_rsStatistiksiswa); ?>">First</a>
      <?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_rsStatistiksiswa > 0) { // Show if not first page ?>
      <a href="<?php printf("%s?pageNum_rsStatistiksiswa=%d%s", $currentPage, max(0, $pageNum_rsStatistiksiswa - 1), $queryString_rsStatistiksiswa); ?>">Previous</a>
      <?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_rsStatistiksiswa < $totalPages_rsStatistiksiswa) { // Show if not last page ?>
      <a href="<?php printf("%s?pageNum_rsStatistiksiswa=%d%s", $currentPage, min($totalPages_rsStatistiksiswa, $pageNum_rsStatistiksiswa + 1), $queryString_rsStatistiksiswa); ?>">Next</a>
      <?php } // Show if not last page ?></td>
    <td><?php if ($pageNum_rsStatistiksiswa < $totalPages_rsStatistiksiswa) { // Show if not last page ?>
      <a href="<?php printf("%s?pageNum_rsStatistiksiswa=%d%s", $currentPage, $totalPages_rsStatistiksiswa, $queryString_rsStatistiksiswa); ?>">Last</a>
      <?php } // Show if not last page ?></td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($rsAbsSis);

mysql_free_result($rsStatistiksiswa);
?>
