<?php require_once('../Connections/database.php'); ?>

<?php
include 'time.php';
ini_set('date.timezone', 'Asia/Jakarta');

$jam_jalan = date('Y-m-d H:i:s');



?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_rsAbsensiGuru = 130;
$pageNum_rsAbsensiGuru = 0;
if (isset($_GET['pageNum_rsAbsensiGuru'])) {
  $pageNum_rsAbsensiGuru = $_GET['pageNum_rsAbsensiGuru'];
}
$startRow_rsAbsensiGuru = $pageNum_rsAbsensiGuru * $maxRows_rsAbsensiGuru;

$colname_rsAbsensiGuru = "-1";
if (isset($_GET['tanggal'])) {
  $colname_rsAbsensiGuru = $_GET['tanggal'];
}
mysql_select_db($database_database, $database);
$query_rsAbsensiGuru = sprintf("SELECT * FROM tr_absensi, tm_guru WHERE tanggal = %s AND tm_guru.id=tr_absensi.tmguru_id", GetSQLValueString($colname_rsAbsensiGuru, "date"));
$query_limit_rsAbsensiGuru = sprintf("%s LIMIT %d, %d", $query_rsAbsensiGuru, $startRow_rsAbsensiGuru, $maxRows_rsAbsensiGuru);
$rsAbsensiGuru = mysql_query($query_limit_rsAbsensiGuru, $database) or die(mysql_error());
$row_rsAbsensiGuru = mysql_fetch_assoc($rsAbsensiGuru);

if (isset($_GET['totalRows_rsAbsensiGuru'])) {
  $totalRows_rsAbsensiGuru = $_GET['totalRows_rsAbsensiGuru'];
} else {
  $all_rsAbsensiGuru = mysql_query($query_rsAbsensiGuru);
  $totalRows_rsAbsensiGuru = mysql_num_rows($all_rsAbsensiGuru);
}
$totalPages_rsAbsensiGuru = ceil($totalRows_rsAbsensiGuru/$maxRows_rsAbsensiGuru)-1;

$queryString_rsAbsensiGuru = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsAbsensiGuru") == false && 
        stristr($param, "totalRows_rsAbsensiGuru") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsAbsensiGuru = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsAbsensiGuru = sprintf("&totalRows_rsAbsensiGuru=%d%s", $totalRows_rsAbsensiGuru, $queryString_rsAbsensiGuru);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Print Laporan Guru Online Harian</title>
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td align="center"><p>&nbsp;</p>
      <table border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td nowrap="nowrap"><img src="images/icon60.png" width="60" height="60" /></td>
          <td align="center" nowrap="nowrap"><h3>Laporan Absensi Guru Harian Via E-learning Kemenag<br > MAN 1 KOTA SUKABUMI<br />Http://man1kotasmi.sch.id</h3></td>
        </tr>
      </table>
      <p><strong>Absensi Guru Harian Online Learning Tanggal :
          <?php
echo date('d-m-Y H:i:s'); 
?>
      </strong><br />
    </p></td>
  </tr>
</table>
<table border="1" align="center"  class="table table-hover"  style="font-size:1vw;">
  <tr>
    <td align="center" nowrap="nowrap"><strong>No.</strong></td>
    <td align="center" nowrap="nowrap"><strong>Nama</strong></td>
    <td align="center" nowrap="nowrap"><strong>Nuptk</strong></td>
    <td align="center" nowrap="nowrap"><strong>Tgl.Absensi</strong></td>
    <td align="center" nowrap="nowrap"><strong>Absensi</strong></td>
    <td align="center" nowrap="nowrap"><strong>Ket. Absensi</strong></td>
  </tr>
   <?php $no=0; do { $no++; ?>
    <tr>
      <td align="center" nowrap="nowrap"><?php echo "$no";?></td>
      <td nowrap="nowrap"><?php echo $row_rsAbsensiGuru['nama']; ?></td>
      <td nowrap="nowrap"><?php echo $row_rsAbsensiGuru['nuptk']; ?></td>
      <td nowrap="nowrap"><?php echo $row_rsAbsensiGuru['tanggal']; ?></td>
      <td nowrap="nowrap"><?php echo $row_rsAbsensiGuru['absen']; ?></td>
      <td align="center" nowrap="nowrap"><?php
 // $timestamp=$row_rsAbsensiGuru['absen'];
date_default_timezone_set('Asia/Jakarta');
  tgl_indo($jam_jalan); 
?>
        <?php// echo tgl_indo($timestamp); ?></td>
    </tr>
    <?php } while ($row_rsAbsensiGuru = mysql_fetch_assoc($rsAbsensiGuru)); ?>
</table>
<p>&nbsp;
  <script>
       window.print();
    </script>    
</body>
</html>
<?php
mysql_free_result($rsAbsensiGuru);

?>
