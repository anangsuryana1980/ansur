<?php require_once('../Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_rsNilaiSis = "-1";
if (isset($_GET['keyword'])) {
  $colname_rsNilaiSis = $_GET['keyword'];
}
mysql_select_db($database_database, $database);
$query_rsNilaiSis = sprintf("SELECT * FROM tr_nilai WHERE `file` LIKE %s ORDER BY tanggal DESC", GetSQLValueString("%" . $colname_rsNilaiSis . "%", "text"));
$rsNilaiSis = mysql_query($query_rsNilaiSis, $database) or die(mysql_error());
$row_rsNilaiSis = mysql_fetch_assoc($rsNilaiSis);
$totalRows_rsNilaiSis = mysql_num_rows($rsNilaiSis);

$colname_rsCariVideo = "-1";
if (isset($_GET['keyword'])) {
  $colname_rsCariVideo = $_GET['keyword'];
}
mysql_select_db($database_database, $database);
$query_rsCariVideo = sprintf("SELECT * FROM tr_nilai, tr_tugas, tr_kelas, tm_guru WHERE `file` LIKE %s AND tr_tugas.id=tr_nilai.trtugas_id AND tr_tugas.trkelas_id=tr_kelas.id AND tm_guru.id=tr_kelas.tmguru_id ORDER BY tr_nilai.tanggal DESC", GetSQLValueString("%" . $colname_rsCariVideo . "%", "text"));
$rsCariVideo = mysql_query($query_rsCariVideo, $database) or die(mysql_error());
$row_rsCariVideo = mysql_fetch_assoc($rsCariVideo);
$totalRows_rsCariVideo = mysql_num_rows($rsCariVideo);

$colname_rsVideoSiswa = "-1";
if (isset($_GET['keyfile'])) {
  $colname_rsVideoSiswa = $_GET['keyfile'];
}
mysql_select_db($database_database, $database);
$query_rsVideoSiswa = sprintf("SELECT * FROM tr_keterampilannilai, tr_keterampilan, tr_kelas, tm_mapel WHERE `file` LIKE %s AND tr_keterampilan.id=tr_keterampilannilai.trketerampilan_id AND tr_keterampilan.trkelas_id=tr_kelas.id AND tr_kelas.tmmapel_id=tm_mapel.id ORDER BY tr_keterampilannilai.tanggal DESC", GetSQLValueString("%" . $colname_rsVideoSiswa . "%", "text"));
$rsVideoSiswa = mysql_query($query_rsVideoSiswa, $database) or die(mysql_error());
$row_rsVideoSiswa = mysql_fetch_assoc($rsVideoSiswa);
$totalRows_rsVideoSiswa = mysql_num_rows($rsVideoSiswa);
$query_rsNilaiSis = "SELECT * FROM tr_nilai WHERE tr_nilai.`file`LIKE '.mp4' ORDER BY tanggal DESC";
$rsNilaiSis = mysql_query($query_rsNilaiSis, $database) or die(mysql_error());
$row_rsNilaiSis = mysql_fetch_assoc($rsNilaiSis);
$totalRows_rsNilaiSis = mysql_num_rows($rsNilaiSis);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Nilai Siswa</title>
</head>

<body>
<p>Tugas &amp; Nilai Siswa</p>
<form id="formSearch" name="formSearch" method="get" action="">
  <table class="table-hover"  style="font-size:1vw;" border="0" align="left" cellpadding="0" cellspacing="0">
    <tr>
      <td align="left" nowrap="nowrap">cari MP4:</td>
      <td align="left"><input type="text" name="keyword" id="keyword" /></td>
      <td align="left">&nbsp;</td>
      <td align="left"><input type="submit" name="button" id="button" value="Cari" /></td>
    </tr>
  </table>
</form>
<p>&nbsp;</p>
<p><a href="dashboard.php?page=nilaisiswa">Nilai Video</a> | <a href="?page=video">Tugas Video</a> | <a href="?page=bahanajar">Bahan Ajar</a> |</p>
<?php if ($totalRows_rsCariVideo > 0) { // Show if recordset not empty ?>
  <p>Tugas Guru :  <strong><?php echo $totalRows_rsCariVideo ?></strong> Video</p>
<table border="0" class="table table-hover"  style="font-size:1vw;">
    <tr>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>id</strong></td>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>nilai</strong></td>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>folder</strong></td>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>file</strong></td>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>tanggal</strong></td>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>Siswa.id</strong></td>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>Tgs.Id</strong></td>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>uji.Id</strong></td>
      <td align="center" nowrap="nowrap" bgcolor="#EFEFEF"><strong>Ket.</strong></td>
    </tr>
    <?php do { ?>
      <tr>
        <td><?php echo $row_rsCariVideo['id']; ?></td>
        <td><?php echo $row_rsCariVideo['nilai']; ?></td>
        <td><?php echo $row_rsCariVideo['folder']; ?></td>
        <td><?php echo $row_rsCariVideo['file']; ?></td>
        <td><?php echo $row_rsCariVideo['tanggal']; ?></td>
        <td><?php echo $row_rsCariVideo['tmsiswa_id']; ?></td>
        <td><?php echo $row_rsCariVideo['trtugas_id']; ?></td>
        <td> <?php echo $row_rsCariVideo['nama']; ?>| <?php echo $row_rsCariVideo['trujian_id']; ?></td>
        <td><?php echo $row_rsCariVideo['kelas']; ?></td>
      </tr>
      <?php } while ($row_rsCariVideo = mysql_fetch_assoc($rsCariVideo)); ?>
  </table>
  <?php } // Show if recordset not empty ?>
<p>&nbsp;</p>

<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($rsNilaiSis);

mysql_free_result($rsCariVideo);

mysql_free_result($rsVideoSiswa);
?>
