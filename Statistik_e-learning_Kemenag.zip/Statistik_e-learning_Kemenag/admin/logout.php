<?php
require_once "function.php";

unset($_SESSION['MM_Username']);
session_destroy();
header("location: index.php");

?>