<?php
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;
  require 'PHPMailer-master/src/Exception.php';
  require 'PHPMailer-master/src/PHPMailer.php';
  require 'PHPMailer-master/src/SMTP.php';

  $mail = new PHPMailer();
  $mail->IsSMTP();

  $mail->SMTPDebug  = 0;  
  $mail->SMTPAuth   = TRUE;
  $mail->SMTPSecure = "tls";
  $mail->Port       = 587;
  $mail->Host       = "smtp.gmail.com";
  $mail->Username   = "manisi1smi@gmail.com";
  $mail->Password   = "anangsuryana992751";

  $mail->IsHTML(true);
  $mail->AddAddress("anangsuryana2@gmail.com", "Anang Suryana");
  $mail->SetFrom("manisi1smi@gmail.com", "SIMKU-MANISI");
  $mail->AddReplyTo("manisi1smi@gmail.com", "Laporan SIMKU-MANISI");
  $mail->AddCC("anangsuryana2@gmail.com", "Anang Suryana SIMKU");
  $mail->Subject = "Tes Iyeu e-mail Saja";
  $content = "<b>This is a Test Email sent via Gmail SMTP Server using PHP mailer class.</b>";

  $mail->MsgHTML($content); 
  if(!$mail->Send()) {
    echo "Error while sending Email.";
    var_dump($mail);
  } else {
    echo "Email sent successfully";
  }
?>