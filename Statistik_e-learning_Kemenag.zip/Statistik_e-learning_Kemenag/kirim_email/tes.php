<?php
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;
  require 'PHPMailer-master/src/Exception.php';
  require 'PHPMailer-master/src/PHPMailer.php';
  require 'PHPMailer-master/src/SMTP.php';

//Deteksi IP Publik sebagai berikut:


if(!empty($_SERVER['HTTP_CLIENT_IP'])){
$ip=$_SERVER['HTTP_CLIENT_IP'];
}
elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
}
else{
$ip = $_SERVER['REMOTE_ADDR'];
}
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);

echo "<br>IP ini adalah:  " .$ip;
echo "<br>Hosname ini adalah:  " .$hostname;

$ipku= $_SERVER['REMOTE_ADDR'];
//deteksi IP sampai sini

ini_set('date.timezone', 'Asia/Jakarta');
echo 'Indonesian Timezone: ' . date('d-m-Y H:i:s');
$date = date('d-m-Y');
$waktu = date('H:i:s');

function format_hari_tanggal($waktu)
{
    $hari_array = array(
        'Minggu',
        'Senin',
        'Selasa',
        'Rabu',
        'Kamis',
        'Jumat',
        'Sabtu'
    );
    $hr = date('w', strtotime($waktu));
    $hari = $hari_array[$hr];
    $tanggal = date('j', strtotime($waktu));
    $bulan_array = array(
        1 => 'Januari',
        2 => 'Februari',
        3 => 'Maret',
        4 => 'April',
        5 => 'Mei',
        6 => 'Juni',
        7 => 'Juli',
        8 => 'Agustus',
        9 => 'September',
        10 => 'Oktober',
        11 => 'November',
        12 => 'Desember',
    );
    $bl = date('n', strtotime($waktu));
    $bulan = $bulan_array[$bl];
    $tahun = date('Y', strtotime($waktu));
    $jam = date( 'H:i:s', strtotime($waktu));
    
    //untuk menampilkan hari, tanggal bulan tahun jam
    //return "$hari, $tanggal $bulan $tahun $jam";

    //untuk menampilkan hari, tanggal bulan tahun
    return "$hari, $tanggal $bulan $tahun";
}

$date=date('Y-m-d');
echo "<br>Hari ini adalah:  ".format_hari_tanggal($date);
$sekarang= format_hari_tanggal($date);
	

  $mail = new PHPMailer();
  $mail->IsSMTP();

  $mail->SMTPDebug  = 0;  
  $mail->SMTPAuth   = TRUE;
  $mail->SMTPSecure = "tls";
  $mail->Port       = 587;
  $mail->Host       = "smtp.gmail.com";
  $mail->Username   = "manisi1smi@gmail.com";
  $mail->Password   = "udinsamsudin6767";

  $mail->IsHTML(true);
  $mail->AddAddress("anangsuryana2@gmail.com", "Anang Suryana");
  $mail->SetFrom("simku@man1kotasmi.sch.id", "Login KAMAD | SIMKU-MANISI");
  $mail->AddReplyTo("simku@man1kotasmi.sch.id", "Laporan login KAMAD SIMKU-MANISI");
  $mail->AddCC("anangsuryana2@gmail.com", "Anang Suryana SIMKU");
  $mail->Subject = "SIMKU-MANISI | LOGIN KAMAD";
  $content = "Salam,<br><br> Hari:<b> $sekarang  Jam: $waktu </b><br><br>Diberitahukan bahwa KAMAD MAN 1 Kota Sukabumi melakukan <b>Login</b> ke SIMKU-MANISI<br><br>IP Perangkat $ipku dan <br>Hostname: $hostname <br>e-mail ini dikirim secara otomatis. <br>Jangan dibalas<br>by <b>Robot SIMKU-MANISI</b>";

  $mail->MsgHTML($content); 
  if(!$mail->Send()) {
    echo "Error while sending Email.";
    var_dump($mail);
  } else {
    echo "Email sent successfully";
  }




//Cek Input histori login ke database
if($login_sukses==true){
    //log user 
     
    $sql = "INSERT INTO user_log(no_daftar,ip,agent,waktu)
    VALUES('$no_daftar','$ip','$agent',now())";
  
    $result = mysqli_query($link,$sql) or die(mysqli_error($link));
}


?>