<?php require_once('Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_rsAbsensiGuru = 130;
$pageNum_rsAbsensiGuru = 0;
if (isset($_GET['pageNum_rsAbsensiGuru'])) {
  $pageNum_rsAbsensiGuru = $_GET['pageNum_rsAbsensiGuru'];
}
$startRow_rsAbsensiGuru = $pageNum_rsAbsensiGuru * $maxRows_rsAbsensiGuru;

mysql_select_db($database_database, $database);
$query_rsAbsensiGuru = "SELECT * FROM tm_guru, tr_absensi WHERE tr_absensi.tmguru_id=tm_guru.id ORDER BY tr_absensi.id DESC";
$query_limit_rsAbsensiGuru = sprintf("%s LIMIT %d, %d", $query_rsAbsensiGuru, $startRow_rsAbsensiGuru, $maxRows_rsAbsensiGuru);
$rsAbsensiGuru = mysql_query($query_limit_rsAbsensiGuru, $database) or die(mysql_error());
$row_rsAbsensiGuru = mysql_fetch_assoc($rsAbsensiGuru);

if (isset($_GET['totalRows_rsAbsensiGuru'])) {
  $totalRows_rsAbsensiGuru = $_GET['totalRows_rsAbsensiGuru'];
} else {
  $all_rsAbsensiGuru = mysql_query($query_rsAbsensiGuru);
  $totalRows_rsAbsensiGuru = mysql_num_rows($all_rsAbsensiGuru);
}
$totalPages_rsAbsensiGuru = ceil($totalRows_rsAbsensiGuru/$maxRows_rsAbsensiGuru)-1;$maxRows_rsAbsensiGuru = 130;
$pageNum_rsAbsensiGuru = 0;
if (isset($_GET['pageNum_rsAbsensiGuru'])) {
  $pageNum_rsAbsensiGuru = $_GET['pageNum_rsAbsensiGuru'];
}
$startRow_rsAbsensiGuru = $pageNum_rsAbsensiGuru * $maxRows_rsAbsensiGuru;

mysql_select_db($database_database, $database);
$query_rsAbsensiGuru = "SELECT * FROM tm_guru, tr_absensi WHERE tr_absensi.tmguru_id=tm_guru.id ORDER BY tr_absensi.absen DESC";
$query_limit_rsAbsensiGuru = sprintf("%s LIMIT %d, %d", $query_rsAbsensiGuru, $startRow_rsAbsensiGuru, $maxRows_rsAbsensiGuru);
$rsAbsensiGuru = mysql_query($query_limit_rsAbsensiGuru, $database) or die(mysql_error());
$row_rsAbsensiGuru = mysql_fetch_assoc($rsAbsensiGuru);

if (isset($_GET['totalRows_rsAbsensiGuru'])) {
  $totalRows_rsAbsensiGuru = $_GET['totalRows_rsAbsensiGuru'];
} else {
  $all_rsAbsensiGuru = mysql_query($query_rsAbsensiGuru);
  $totalRows_rsAbsensiGuru = mysql_num_rows($all_rsAbsensiGuru);
}
$totalPages_rsAbsensiGuru = ceil($totalRows_rsAbsensiGuru/$maxRows_rsAbsensiGuru)-1;

$queryString_rsAbsensiGuru = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_rsAbsensiGuru") == false && 
        stristr($param, "totalRows_rsAbsensiGuru") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_rsAbsensiGuru = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_rsAbsensiGuru = sprintf("&totalRows_rsAbsensiGuru=%d%s", $totalRows_rsAbsensiGuru, $queryString_rsAbsensiGuru);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Guru</title>
</head>

<body>
<p><a href="print_absensi_guru_perhari.php?tanggal=<?php echo $row_rsAbsensiGuru['tanggal']; ?>" target="_blank"> <i class="fa fa-print" aria-hidden="true"></i> </a>  Login Harian Guru  Online Learning</p>
<p><a href="print_absensi_guru_perhari.php?tanggal=<?php echo $row_rsAbsensiGuru['tanggal']; ?>" target="_blank">  </a></p>
<table border="0">
  <tr>
    <td><?php if ($pageNum_rsAbsensiGuru > 0) { // Show if not first page ?>
      <a href="<?php printf("%s?pageNum_rsAbsensiGuru=%d%s", $currentPage, 0, $queryString_rsAbsensiGuru); ?>">First</a>
      <?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_rsAbsensiGuru > 0) { // Show if not first page ?>
      <a href="<?php printf("%s?pageNum_rsAbsensiGuru=%d%s", $currentPage, max(0, $pageNum_rsAbsensiGuru - 1), $queryString_rsAbsensiGuru); ?>"> | Previous | </a>
      <?php } // Show if not first page ?></td>
    <td><?php if ($pageNum_rsAbsensiGuru < $totalPages_rsAbsensiGuru) { // Show if not last page ?>
      <a href="<?php printf("%s?pageNum_rsAbsensiGuru=%d%s", $currentPage, min($totalPages_rsAbsensiGuru, $pageNum_rsAbsensiGuru + 1), $queryString_rsAbsensiGuru); ?>"> | Next | </a>
      <?php } // Show if not last page ?></td>
    <td><?php if ($pageNum_rsAbsensiGuru < $totalPages_rsAbsensiGuru) { // Show if not last page ?>
      <a href="<?php printf("%s?pageNum_rsAbsensiGuru=%d%s", $currentPage, $totalPages_rsAbsensiGuru, $queryString_rsAbsensiGuru); ?>">| Last | </a>
      <?php } // Show if not last page ?></td>
  </tr>
</table>
</p>
<table border="0" align="center"  class="table table-hover"  style="font-size:1vw;">
  <tr>
    <td align="center"><strong>No.</strong></td>
    <td align="center"><strong>No.Id</strong></td>
    <td align="center"><strong>Id.Guru</strong></td>
    <td align="center"><strong>Tgl.Absensi</strong></td>
    <td align="center"><strong>Absensi</strong></td>
    <td align="center" nowrap="nowrap"><strong>Ket. Absensi
      <?php
include 'time.php';
ini_set('date.timezone', 'Asia/Jakarta');

$jam_jalan = date('Y-m-d H:i:s');

?>
    </strong></td>
  </tr>
   <?php $no=0; do { $no++; ?>
    <tr>
      <td align="center"><?php echo "$no";?></td>
      <td><?php echo $row_rsAbsensiGuru['nama']; ?></td>
      <td><?php echo $row_rsAbsensiGuru['nuptk']; ?></td>
      <td><?php echo $row_rsAbsensiGuru['tanggal']; ?></td>
      <td><?php echo $row_rsAbsensiGuru['absen']; ?></td>
      <td align="center" nowrap="nowrap"><?php
  $timestamp=$row_rsAbsensiGuru['absen'];
date_default_timezone_set('Asia/Jakarta');
  tgl_indo($jam_jalan); 
?>
        <?php echo tgl_indo($timestamp); ?></td>
    </tr>
    <?php } while ($row_rsAbsensiGuru = mysql_fetch_assoc($rsAbsensiGuru)); ?>
</table>
<p>&nbsp;
</body>
</html>
<?php
mysql_free_result($rsAbsensiGuru);
?>
