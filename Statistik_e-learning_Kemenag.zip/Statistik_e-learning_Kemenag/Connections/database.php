<?php
include "parser-php-version.php";
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_database = "localhost";
$database_database = "namadatabase_samakan_dengan_database_elearningnya";
$username_database = "username_samakan_dengan_database_elearningnya";
$password_database = "password-database-elearning";
$database = mysqli_connect($hostname_database, $username_database, $password_database) or trigger_error(mysql_error(),E_USER_ERROR); 
?>