<?php require_once('Connections/database.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_rsNotifGuruKelas = 1000;
$pageNum_rsNotifGuruKelas = 0;
if (isset($_GET['pageNum_rsNotifGuruKelas'])) {
  $pageNum_rsNotifGuruKelas = $_GET['pageNum_rsNotifGuruKelas'];
}
$startRow_rsNotifGuruKelas = $pageNum_rsNotifGuruKelas * $maxRows_rsNotifGuruKelas;

mysql_select_db($database_database, $database);
$query_rsNotifGuruKelas = "SELECT * FROM notifikasi ORDER BY tanggal DESC";
$query_limit_rsNotifGuruKelas = sprintf("%s LIMIT %d, %d", $query_rsNotifGuruKelas, $startRow_rsNotifGuruKelas, $maxRows_rsNotifGuruKelas);
$rsNotifGuruKelas = mysql_query($query_limit_rsNotifGuruKelas, $database) or die(mysql_error());
$row_rsNotifGuruKelas = mysql_fetch_assoc($rsNotifGuruKelas);

if (isset($_GET['totalRows_rsNotifGuruKelas'])) {
  $totalRows_rsNotifGuruKelas = $_GET['totalRows_rsNotifGuruKelas'];
} else {
  $all_rsNotifGuruKelas = mysql_query($query_rsNotifGuruKelas);
  $totalRows_rsNotifGuruKelas = mysql_num_rows($all_rsNotifGuruKelas);
}
$totalPages_rsNotifGuruKelas = ceil($totalRows_rsNotifGuruKelas/$maxRows_rsNotifGuruKelas)-1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>Aktifitas Siswa Terhadap Mata Pelajaran</p>
<table width="100%" border="0" class="table table-hover"  style="font-size:1vw;">
  <tr>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>No.</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>ID</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Keterangan</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Tanggal</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Ket.
      <?php
include 'time.php';
ini_set('date.timezone', 'Asia/Jakarta');

$jam_jalan = date('Y-m-d H:i:s');

?>
    </strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Status</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Kls.Id</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>User</strong></td>
    <td align="center" nowrap="nowrap" bgcolor="#CCCCCC"><strong>Link</strong></td>
  </tr>
  <?php $no=0; do { $no++; ?>
    <tr>
      <td align="center" nowrap="nowrap"><?php echo "$no";?></td>
      <td nowrap="nowrap"><?php echo $row_rsNotifGuruKelas['id']; ?></td>
      <td><?php echo $row_rsNotifGuruKelas['keterangan']; ?></td>
      <td nowrap="nowrap"><?php echo $row_rsNotifGuruKelas['tanggal']; ?></td>
      <td align="center" nowrap="nowrap"><?php
  $timestamp=$row_rsNotifGuruKelas['tanggal'];
  
date_default_timezone_set('Asia/Jakarta');
  tgl_indo($jam_jalan); 
?>
      <?php echo tgl_indo($timestamp); ?></td>
      <td nowrap="nowrap"><?php echo $row_rsNotifGuruKelas['status']; ?></td>
      <td nowrap="nowrap"><?php echo $row_rsNotifGuruKelas['trkelas_id']; ?></td>
      <td nowrap="nowrap"><?php echo $row_rsNotifGuruKelas['user']; ?></td>
      <td nowrap="nowrap"><?php echo $row_rsNotifGuruKelas['link']; ?></td>
  </tr>
    <?php } while ($row_rsNotifGuruKelas = mysql_fetch_assoc($rsNotifGuruKelas)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($rsNotifGuruKelas);
?>
